const file = require('../src/purchaseOrder');
const expect = require("chai").expect;

var inventoryThreshold = 300;
const inventoryBalance = [
    { name: 'soldout', quantity: 0, test: 0, des: `inventory threshold ${inventoryThreshold} and 0` },
    { name: 'low', quantity: 50, test: 40, des: `inventory threshold ${inventoryThreshold} and 40` },
    { name: 'high', quantity: 600, test: 500, des: `inventory threshold ${inventoryThreshold} and 500` },
    { name: 'same', quantity: inventoryThreshold - 100, test: 600, des: `inventory threshold ${inventoryThreshold} and 600` },
]
const inventoryEquivalance = [
    { name: 'soldout', quantity: 10, test: 12, des: `inventory threshold ${inventoryThreshold} and 12` },
    { name: 'low', quantity: 30, test: 30, des: `inventory threshold ${inventoryThreshold} and 30` },
    { name: 'high', quantity: 800, test: 700, des: `inventory threshold ${inventoryThreshold} and 800` },
    { name: 'same', quantity: 0, test: 21, des: `inventory threshold ${inventoryThreshold} and 21` },
]
var productStatus = function (product, inventory, inventoryThreshold) {
    var quantity, i;
    if (product === inventory.name) {
        quantity = inventory.quantity;
        if (quantity === 0)
            return "soldout";
        else if (quantity < inventoryThreshold)
            return "available-to-all";
        else return "limited"
    }

    return "invalid";
}
var inventoryResults = [...inventoryBalance, ...inventoryEquivalance]

describe('inventory rendering', function () {
    inventoryResults.map(res => {
        it("Should return " + productStatus(res.name, { name: res.name, quantity: res.test }, inventoryThreshold) + ' when given ' + res.des, function () {
            expect(file.productStatus(res.name, inventoryResults, inventoryThreshold)).to.be.a(productStatus(res.name, { name: res.name, quantity: res.test }, inventoryThreshold))
        })
    })
})