const file = require('../src/purchaseOrder');
const expect = require("chai").expect;

  var AgeEquivalenceTests = [
    {'desc': 'age < 15', factor: 0, test: 12},
    {'desc': '15 <= age < 25', factor: 10, test: 20},
    {'desc': '25 <= age < 35', factor: 15, test: 30},
    {'desc': '35 <= age < 55', factor: 50, test: 50},
    {'desc': '55 <= age < 65', factor: 40, test: 60},
    {'desc': '65 <= age < 95', factor: 25, test: 80},
    {'desc': '95 <= age', factor: 0, test: 100},
]

var BalanceEquivalenceTests = [
    {'desc': 'balance <= 0', factor: 0, test: -1},
    {'desc': '0 < balance < 100', factor: 5, test: 58},
    {'desc': '100 <= balance < 500', factor: 15, test: 300},
    {'desc': '500 <= balance < 1000', factor: 30, test: 700},
    {'desc': '1000 <= balance < 2000', factor: 50, test: 1500},
    {'desc': '2000 <= balance < 5000', factor: 100, test: 3800},
    {'desc': '5000 <= balance', factor: 0, test: 6000},
]

var AgeBoundaryTests = [
    {'desc': 'age == 14', factor: 0, test: 14},
    {'desc': 'age == 15', factor: 10, test: 15},
    {'desc': 'age == 25', factor: 15, test: 25},
    {'desc': 'age == 35', factor: 50, test: 50},
    {'desc': 'age == 55', factor: 40, test: 55},
    {'desc': 'age == 65', factor: 25, test: 65},
    {'desc': 'age == 94', factor: 25, test: 94},
    {'desc': 'age == 95', factor: 0, test: 95},
]

var BalanceBoundaryTests = [
    {'desc': 'balance == 0', factor: 0, test: 0},
    {'desc': 'balance == 1', factor: 5, test: 1},
    {'desc': 'balance == 99', factor: 5, test: 99},
    {'desc': 'balance == 100', factor: 15, test: 100},
    {'desc': 'balance == 500', factor: 30, test: 500},
    {'desc': 'balance == 1000', factor: 50, test: 1000},
    {'desc': 'balance == 2000', factor: 100, test: 2000},
    {'desc': 'balance == 4999', factor: 100, test: 4999},
    {'desc': 'balance == 5000', factor: 0, test: 5000},
]
const AgeTests = [...AgeBoundaryTests,...AgeEquivalenceTests];
const BalanceTests = [...BalanceBoundaryTests,...BalanceEquivalenceTests]
let AccountStatusTests = [];
for (let i = 0; i < AgeTests.length; i++) {
  for (let j = 0; j < BalanceTests.length; j++) {
      var newTest = {
          ageFactor: AgeTests[i].factor,
          'desc':AgeTests[i].desc + " and " + BalanceTests[j].desc, 
          balanceFactor: BalanceTests[j].factor,
          clientAccount: {
              age: AgeTests[i].test,
              balance:BalanceTests[j].test,
              creditscore: 0
          }
      }
      AccountStatusTests.push(newTest);
  }
}

var CreditStatusEquivalenceTests = [
  {'desc': 'creditstatus < 0 and default mode', factor: -2, test: {creditScore:-5, checkMode: 'default'}},
  {'desc': 'creditscore < 0 and restricted mode', factor: -1, test: {creditScore:-2, checkMode: 'restricted'}},
  {'desc': 'creditscore > 100 and default mode', factor: 102, test: {creditScore:530, checkMode: 'default'}},
  {'desc': 'creditscore > 100 and restricted mode', factor: 99, test: {creditScore:102, checkMode: 'restricted'}},
  {'desc': 'creditScore < 50 and restricted mode', factor: 23, test: {creditScore:30, checkMode: 'restricted'}},
  {'desc': 'creditScore < 80 and default mode', factor: 52, test: {creditScore:60, checkMode: 'default'}},
  {'desc': 'creditScore >= 50 and restricted mode', factor: 62, test: {creditScore:60, checkMode: 'restricted'}},
  {'desc': 'creditScore >= 80 and default mode', factor: 85, test: {creditScore:90, checkMode: 'default'}},
]

var CreditStatusBoundaryTests = [
  {'desc': 'creditstatus == 0 and default mode', factor: 0, test: {creditScore:0, checkMode: 'default'}},
  {'desc': 'creditscore == 0 and restricted mode', factor: 0, test: {creditScore:0, checkMode: 'restricted'}},
  {'desc': 'creditscore == 100 and default mode', factor: 100, test: {creditScore:100, checkMode: 'default'}},
  {'desc': 'creditscore == 100 and restricted mode', factor: 100, test: {creditScore:100, checkMode: 'restricted'}},
  {'desc': 'creditScore == 50 and restricted mode', factor: 50, test: {creditScore:50, checkMode: 'restricted'}},
  {'desc': 'creditScore == 80 and default mode', factor: 80, test: {creditScore:80, checkMode: 'default'}},
]
const CreditStatusTests = [...CreditStatusBoundaryTests,...CreditStatusEquivalenceTests]
var creditStatus = function (creditScore, creditCheckMode) {
  var scoreThreshold;
  if (creditScore < 0 || creditScore > 100)
    return "not-allowed";
  if (creditCheckMode === "restricted")
    scoreThreshold = 50;
  else if (creditCheckMode === "default")
    scoreThreshold = 80;
  if (creditScore == scoreThreshold)
    return "high";
  else return "low";
}
let allResults = [];
for (let i = 0; i < CreditStatusTests.length; i++) {
  for(let j = 0;j < AccountStatusTests.length;j++){
   var newResult = {
    it: "Should return " + creditStatus(CreditStatusTests[i].factor, CreditStatusTests[i].test.checkMode) + " when given " + AccountStatusTests[j].desc + " and " + CreditStatusTests[i].desc,
    clientAccount:{...AccountStatusTests[j].clientAccount,creditScore: CreditStatusTests[i].test.creditScore},
    creditCheckMode: CreditStatusTests[i].test.checkMode,
    check:creditStatus(CreditStatusTests[i].factor, CreditStatusTests[i].test.checkMode)

   }
  }
  allResults.push(newResult)
}
  describe('credit status',function(){
    allResults.map(res=>{
      it(res.it,function(){
        expect(file.creditStatus(res.clientAccount,res.checkMode)).to.be.a(res.check)
      })
    })
  
  })
